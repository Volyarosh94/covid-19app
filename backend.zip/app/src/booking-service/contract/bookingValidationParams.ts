export interface BookingValidationParams {
    dateFrom: string;
    dateTo: string;
    timeFrom: string;
    timeTo: string;
    locationId: string;
    userId: string;
}
