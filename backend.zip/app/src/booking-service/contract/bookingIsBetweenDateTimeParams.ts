export interface BookingIsBetweenDateTimeParams {
    oldBookingStartDate: string;
    newBookingStartDate: string;
    newBookingEndDate: string;
    newBookingStartTime: string;
    newBookingEndTime: string;
    oldBookingStartTime: string;
    oldBookingEndTime: string;
}
