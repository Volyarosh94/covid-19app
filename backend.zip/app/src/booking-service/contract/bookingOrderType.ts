export enum BookingOrderType {
    ASC = "ASC",
    DESC = "DESC"
}
