export enum BookingType {
    CUSTOM = "custom",
    DAILY = "daily",
    WEEKLY = "weekly"
}
