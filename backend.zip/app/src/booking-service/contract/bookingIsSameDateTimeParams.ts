export interface BookingIsSameDateTimeParams {
    oldBookingStartDate: string;
    newBookingStartDate: string;
    newBookingStartTime: string;
    newBookingEndTime: string;
    oldBookingStartTime: string;
    oldBookingEndTime: string;
}
