export interface QuestionnaireBooking {
    bookingId: string;
    locationId: string;
}
