export interface BookingIdWithDate{
    date: string,
    bookingId: string
}
