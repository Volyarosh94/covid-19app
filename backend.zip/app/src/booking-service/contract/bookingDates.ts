export interface BookingDates{
 dateFrom: string;
 dateTo: string;
}
