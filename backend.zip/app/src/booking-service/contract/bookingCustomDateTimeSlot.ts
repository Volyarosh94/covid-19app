export interface BookingCustomDateTimeSlot {
    date: string;
    slots: string[];
}
