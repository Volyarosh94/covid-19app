export const BOOKING_SERVICE = Symbol("BOOKING_SERVICE");
