export interface ResourceCreateRequest {
    name: string;
    isAvailable: boolean;
}
