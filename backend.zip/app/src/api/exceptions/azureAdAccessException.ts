export class AzureADAccessException extends Error {
    constructor(message: string) {
        super(message);
    }
}
