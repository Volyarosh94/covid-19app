export interface GoogleLocations {
    [key: string]: string;
}
