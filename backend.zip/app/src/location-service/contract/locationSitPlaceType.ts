export enum LocationSitPlaceType {
    SIT_DESK = "sitDesk",
    SIT_STAND = "sitStand",
    ROOM = "room"
}
