export interface LocationUpdateRequest {
    locationName?: string;
    locationAddress?: string;
    city?: string,
    country?: string,
    region?: string,
}
