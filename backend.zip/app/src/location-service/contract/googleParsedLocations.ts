export interface GoogleParsedLocations {
    region: string;
    country: string;
    [key: string]: string;
}
