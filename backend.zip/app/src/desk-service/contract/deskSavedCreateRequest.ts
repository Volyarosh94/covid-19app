export interface SavedDeskCreateRequest {
    userId: string;
    locationId: string;
    floorId: string;
    deskId: string;
}
