export const DESK_SERVICE = Symbol("DESK_SERVICE");
