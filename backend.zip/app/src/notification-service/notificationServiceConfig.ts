export class NotificationServiceConfig {
    baseUrl: string;
}
