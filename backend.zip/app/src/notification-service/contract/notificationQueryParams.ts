export interface NotificationQueryParams {
    page?: number;
}
