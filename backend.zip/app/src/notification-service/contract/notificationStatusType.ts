export enum NOTIFICATION_STATUS_TYPE {
    SENT = "sent",
    PENDING = "pending"
}
