export enum QuestionnaireNotificationType {
    QUESTIONNAIRE_REMINDER = "sendQuestionnaireReminder",
    QUESTIONNAIRE_CANCEL_BOOKING_NOTIFICATION = "sendQuestionnaireBasedCancelBookingNotification",
    QUESTIONNAIRE_START_NOTIFICATION = "sendQuestionnaireStartNotification"
}
