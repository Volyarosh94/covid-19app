export enum NotificationRecipientType {
    ALL = "all",
    HAS_BOOKING = "whoHasBooking"
}
