export interface DisabledAndReservedDates {
    disabledDates: string[];
    reservedDates: string[];
}
