export interface UpdateQuestionRequest {
    questionText?: string;
    questionDetails?: string;
    isPositive?: boolean;
}
