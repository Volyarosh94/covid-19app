export interface AddQuestionRequest {
    questionText: string;
    questionDetails?: string;
    isPositive: boolean;
}
