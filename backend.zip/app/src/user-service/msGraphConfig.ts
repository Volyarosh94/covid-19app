export class MsGraphConfig {
    graphUrl: string;
    clientId: string;
    tenantId: string;
    grant_type: string;
    authTokenUrl: string;
    clientSecret: string;
    scope: string;
}
