export const USER_SERVICE = Symbol("USER_SERVICE");
