export interface SectionNeighbour {
    id: string;
    name: string;
    surname: string;
    deskId: string;
    sectionId: number;

}
