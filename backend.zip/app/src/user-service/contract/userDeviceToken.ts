export interface UserDeviceToken {
    id: string;
    deviceToken: string;
    userId: string;
}
