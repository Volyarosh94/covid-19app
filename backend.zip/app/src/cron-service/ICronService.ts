export interface ICronService {
    SendQuestionnaireScheduledNotifications(): void;
}
