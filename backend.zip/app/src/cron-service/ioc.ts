export const CRON_SERVICE = Symbol("CRON_SERVICE");
