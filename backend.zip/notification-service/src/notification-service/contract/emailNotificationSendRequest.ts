export interface EmailNotificationSendRequest {
    recipients: string[];
    notificationSubject: string;
    notificationText: string;
    
}
